/* PERMITTED COMMANDS
   move, turnLeft, turnRight, treeLeft, treeRight, treeFront, onLeaf, putLeaf, removeLeaf, mushroomFront
   JAVA
   if, while, for
*/
   
class MyClara extends Clara { 
    /**
     * In the 'run()' method you can write your program for Clara 
     */
    void run() {
        // TODO: Write your code below
         for (int turn = 0; turn < 16; turn ++){
            if (treeFront()){
                turnLeft();
                move();
                turnRight();
                move();
            }
        }
    }
}
 